import kotlin.math.*

data class Point(
    val x: Double,
    val y: Double,
)

class Triangle private constructor(
    private val p1: Point,
    private val p2: Point,
    private val p3: Point,
) {
    init {
        require(!arePointsCollinear(p1, p2, p3)) { "Vertices cannot be collinear." }
    }

    companion object {
        fun create(
            p1: Point,
            p2: Point,
            p3: Point,
        ): Triangle? =
            if (arePointsCollinear(p1, p2, p3)) {
                null
            } else {
                Triangle(p1, p2, p3)
            }

        private fun arePointsCollinear(
            p1: Point,
            p2: Point,
            p3: Point,
        ): Boolean = (p2.y - p1.y) * (p3.x - p2.x) == (p3.y - p2.y) * (p2.x - p1.x)
    }

    fun print() {
        println("Triangle with vertices: p1($p1), p2($p2), p3($p3)")
    }

    fun perimeter(): Double = distance(p1, p2) + distance(p2, p3) + distance(p3, p1)

    fun area(): Double = 0.5 * abs(p1.x * (p2.y - p3.y) + p2.x * (p3.y - p1.y) + p3.x * (p1.y - p2.y))

    fun rotate(degrees: Double) {
        val radians = Math.toRadians(degrees)
        val centroid = centroid()

        val rotatePoint = { point: Point ->
            val translatedX = point.x - centroid.x
            val translatedY = point.y - centroid.y
            val rotatedX = translatedX * cos(radians) - translatedY * sin(radians)
            val rotatedY = translatedX * sin(radians) + translatedY * cos(radians)
            Point(rotatedX + centroid.x, rotatedY + centroid.y)
        }

        val newP1 = rotatePoint(p1)
        val newP2 = rotatePoint(p2)
        val newP3 = rotatePoint(p3)

        val newTriangle = create(newP1, newP2, newP3)
        if (newTriangle != null) {
            println("Triangle rotated by $degrees degrees:")
            newTriangle.print()
        }
    }

    private fun centroid(): Point {
        val x = (p1.x + p2.x + p3.x) / 3
        val y = (p1.y + p2.y + p3.y) / 3
        return Point(x, y)
    }

    private fun distance(
        p1: Point,
        p2: Point,
    ): Double = sqrt((p2.x - p1.x).pow(2) + (p2.y - p1.y).pow(2))
}

fun main() {
    val p1 = Point(0.0, 0.0)
    val p2 = Point(4.0, 0.0)
    val p3 = Point(2.0, 3.0)

    val triangle = Triangle.create(p1, p2, p3)
    if (triangle != null) {
        triangle.print()
        println("Perimeter: ${triangle.perimeter()}")
        println("Area: ${triangle.area()}")
        triangle.rotate(90.0)
    } else {
        println("The points provided form a collinear set.")
    }
}
