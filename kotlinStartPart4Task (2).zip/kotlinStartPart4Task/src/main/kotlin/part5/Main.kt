package part5

import kotlin.math.pow

fun main() {
    val number = 2
    number.powAndThen(3) { result ->
        println("Результат: $result") // Выведет "Результат: 8"
    }

    3.displayTypeInfo() // Выведет "это Int"
    "a".displayTypeInfo() // Выведет "это String"
    true.displayTypeInfo() // Выведет "тип у true неизвестен"
    DataType.DoubleType(1.4).displayTypeInfo() // Выведет "это DoubleType со значением 1.4"
    DataType.UnitType.displayTypeInfo() // Выведет "это Unit"
}

fun Int.pow(exponent: Int): Int = this.toDouble().pow(exponent).toInt()

fun Int.powAndThen(
    exponent: Int,
    action: (Int) -> Unit,
) {
    val result = this.toDouble().pow(exponent).toInt()
    action(result)
}

// Определение sealed class DataType
sealed class DataType {
    data class DoubleType(
        val value: Double,
    ) : DataType()

    object UnitType : DataType()
}

// Extension функция для DataType
fun DataType.displayDataTypeInfo() {
    when (this) {
        is DataType.DoubleType -> println("это DoubleType со значением ${this.value}")
        is DataType.UnitType -> println("это Unit")
    }
}

// Обновлённая функция displayTypeInfo для generic типов
fun <T> T.displayTypeInfo() {
    when (this) {
        is String -> println("это String")
        is Int -> println("это Int")
        is DataType -> this.displayDataTypeInfo()
        else -> println("тип у $this неизвестен")
    }
}
