import java.util.*

fun main() {
    val (casesStr, message) = readInput()
    val cases = casesStr.toInt()
    val result =
        when (cases) {
            1 -> message
            else ->
                message.takeIf { it.length % 2 == 0 }?.chunked(message.length / cases)?.joinToString(",")
                    ?: "Слово не может быть равномерно разделено."
        }

    println(result)
}

fun readInput(): Pair<String, String> {
    val scanner = Scanner(System.`in`)
    val input = scanner.nextLine().split(" | ").map(String::trim)
    return Pair(input[0], input[1])
}
